package com.example.demo.config;

import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.apache.catalina.connector.Connector;

@Configuration
public class MultiplePortsConfig {

  @Bean
  public WebServerFactoryCustomizer<TomcatServletWebServerFactory> servletContainer() {
    return server -> {
      // Port 9090
      Connector connector1 = new Connector(TomcatServletWebServerFactory.DEFAULT_PROTOCOL);
      connector1.setPort(9090);
      server.addAdditionalTomcatConnectors(connector1);

      // Port 7070
      // Connector connector2 = new
      // Connector(TomcatServletWebServerFactory.DEFAULT_PROTOCOL);
      // connector2.setPort(7070);
      // server.addAdditionalTomcatConnectors(connector2);
    };
  }
}
