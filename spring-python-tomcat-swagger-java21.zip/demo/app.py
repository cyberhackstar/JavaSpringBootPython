from flask import Flask, request
from flask_restx import Api, Resource, fields

app = Flask(__name__)
api = Api(app, version='1.0', title='User API',
          description='A simple User Management API')

# In-memory 'database'
users = {}
next_id = 1

# Define the User model for Swagger
user_model = api.model('User', {
    'id': fields.Integer(readOnly=True, description='User unique ID'),
    'name': fields.String(required=True, description='User name'),
    'email': fields.String(required=True, description='User email')
})

# Namespace (optional for grouping)
ns = api.namespace('users', description='User operations')

# 1. GET all users
@ns.route('/')
class UserList(Resource):
    @ns.doc('list_users')
    @ns.marshal_list_with(user_model)
    def get(self):
        """List all users"""
        return list(users.values()), 200

    @ns.doc('create_user')
    @ns.expect(user_model)
    @ns.marshal_with(user_model, code=201)
    def post(self):
        """Create a new user"""
        global next_id
        data = request.json
        user = {
            'id': next_id,
            'name': data['name'],
            'email': data['email']
        }
        users[next_id] = user
        next_id += 1
        return user, 201

# 2. GET, PUT, DELETE user by ID
@ns.route('/<int:user_id>')
@ns.response(404, 'User not found')
@ns.param('user_id', 'The user identifier')
class User(Resource):
    @ns.doc('get_user')
    @ns.marshal_with(user_model)
    def get(self, user_id):
        """Fetch a user given its ID"""
        user = users.get(user_id)
        if user:
            return user
        api.abort(404, "User not found")

    @ns.doc('update_user')
    @ns.expect(user_model)
    @ns.marshal_with(user_model)
    def put(self, user_id):
        """Update a user given its ID"""
        user = users.get(user_id)
        if user:
            data = request.json
            user['name'] = data.get('name', user['name'])
            user['email'] = data.get('email', user['email'])
            return user
        api.abort(404, "User not found")

    @ns.doc('delete_user')
    @ns.response(204, 'User deleted')
    def delete(self, user_id):
        """Delete a user given its ID"""
        if user_id in users:
            del users[user_id]
            return '', 204
        api.abort(404, "User not found")

# Main entry
if __name__ == '__main__':
    app.run(debug=True, port=8080)
