import java.io.*;

public class IOConceptsDemo {

  public static void main(String[] args) throws IOException, ClassNotFoundException {
    byteAndCharacterStreams();
    fileReaderWriterExample();
    bufferedReaderExample();
    serializationExample();
  }

  // 1. BYTE & CHARACTER STREAMS
  static void byteAndCharacterStreams() throws IOException {
    System.out.println("=== BYTE & CHARACTER STREAMS ===");

    // BYTE STREAM: write & read using FileOutputStream and FileInputStream
    FileOutputStream fos = new FileOutputStream("byte_output.txt");
    fos.write("Byte Stream Example".getBytes());
    fos.close();

    FileInputStream fis = new FileInputStream("byte_output.txt");
    int b;
    System.out.print("Read from byte stream: ");
    while ((b = fis.read()) != -1) {
      System.out.print((char) b);
    }
    fis.close();
    System.out.println("\n");

    // CHARACTER STREAM: write & read using FileWriter and FileReader
    FileWriter fw = new FileWriter("char_output.txt");
    fw.write("Character Stream Example");
    fw.close();

    FileReader fr = new FileReader("char_output.txt");
    int c;
    System.out.print("Read from char stream: ");
    while ((c = fr.read()) != -1) {
      System.out.print((char) c);
    }
    fr.close();
    System.out.println("\n");
  }

  // 2. FILEREADER & FILEWRITER
  static void fileReaderWriterExample() throws IOException {
    System.out.println("=== FILEREADER & FILEWRITER ===");

    // Writing to file
    FileWriter writer = new FileWriter("sample.txt");
    writer.write("This is written using FileWriter.\nSecond line here.");
    writer.close();

    // Reading from file
    FileReader reader = new FileReader("sample.txt");
    int data;
    System.out.print("FileReader output: ");
    while ((data = reader.read()) != -1) {
      System.out.print((char) data);
    }
    reader.close();
    System.out.println("\n");
  }

  // 3. BUFFEREDREADER
  static void bufferedReaderExample() throws IOException {
    System.out.println("=== BUFFEREDREADER ===");

    BufferedReader br = new BufferedReader(new FileReader("sample.txt"));
    String line;
    System.out.println("Reading line by line:");
    while ((line = br.readLine()) != null) {
      System.out.println("Line: " + line);
    }
    br.close();
    System.out.println();
  }

  // 4. SERIALIZATION & DESERIALIZATION
  static void serializationExample() throws IOException, ClassNotFoundException {
    System.out.println("=== SERIALIZATION & DESERIALIZATION ===");

    // Serialize object to file
    ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("user.ser"));
    User user = new User("EvilCoder", 31337);
    oos.writeObject(user);
    oos.close();
    System.out.println("Serialized User: " + user);

    // Deserialize object from file
    ObjectInputStream ois = new ObjectInputStream(new FileInputStream("user.ser"));
    User loadedUser = (User) ois.readObject();
    ois.close();
    System.out.println("Deserialized User: " + loadedUser);
    System.out.println();
  }

  // Serializable class
  static class User implements Serializable {
    private static final long serialVersionUID = 1L;
    String username;
    int level;

    User(String username, int level) {
      this.username = username;
      this.level = level;
    }

    @Override
    public String toString() {
      return "User{username='" + username + "', level=" + level + "}";
    }
  }
}
