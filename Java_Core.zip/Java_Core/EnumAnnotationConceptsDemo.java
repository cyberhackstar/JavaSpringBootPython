import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;

public class EnumAnnotationConceptsDemo {

  public static void main(String[] args) throws Exception {
    enumBasicsExample();
    enumSwitchExample();
    builtInAnnotationsExample();
    customAnnotationsExample();
  }

  // 1. ENUM BASICS
  static void enumBasicsExample() {
    System.out.println("=== ENUM BASICS ===");

    Day today = Day.MONDAY;
    System.out.println("Today is: " + today);

    // Loop through enum values
    for (Day day : Day.values()) {
      System.out.println(day);
    }
    System.out.println();
  }

  enum Day {
    MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY
  }

  // 2. ENUM WITH SWITCH
  static void enumSwitchExample() {
    System.out.println("=== ENUM WITH SWITCH ===");

    Day today = Day.FRIDAY;

    switch (today) {
      case MONDAY:
        System.out.println("Start of work week!");
        break;
      case FRIDAY:
        System.out.println("Almost weekend!");
        break;
      case SUNDAY:
        System.out.println("Relax, it's Sunday.");
        break;
      default:
        System.out.println("Midweek days...");
    }
    System.out.println();
  }

  // 3. BUILT-IN ANNOTATIONS
  static void builtInAnnotationsExample() {
    System.out.println("=== BUILT-IN ANNOTATIONS ===");

    SampleClass sample = new SampleClass();
    sample.show();

    System.out.println();
  }

  static class ParentClass {
    void show() {
      System.out.println("Parent Show");
    }
  }

  static class SampleClass extends ParentClass {
    @Override // Built-in annotation to ensure correct overriding
    void show() {
      System.out.println("Child Show (Overridden)");
    }

    @Deprecated
    void oldMethod() {
      System.out.println("This method is deprecated.");
    }
  }

  // 4. CUSTOM ANNOTATIONS
  static void customAnnotationsExample() throws Exception {
    System.out.println("=== CUSTOM ANNOTATIONS ===");

    CustomService service = new CustomService();
    service.run();

    // Reflection to read custom annotation
    Method method = CustomService.class.getMethod("run");
    if (method.isAnnotationPresent(Info.class)) {
      Info info = method.getAnnotation(Info.class);
      System.out.println("Author: " + info.author());
      System.out.println("Version: " + info.version());
    }

    System.out.println();
  }

  // Defining a Custom Annotation
  @Retention(RetentionPolicy.RUNTIME) // Available at runtime via reflection
  @interface Info {
    String author();

    String version();
  }

  static class CustomService {
    @Info(author = "BlackHAT", version = "1.0")
    public void run() {
      System.out.println("Service is running...");
    }
  }
}
