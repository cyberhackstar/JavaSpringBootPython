public class ExceptionConceptsDemo {

  public static void main(String[] args) {
    tryCatchFinallyExample();
    throwThrowsExample();
    checkedVsUncheckedExample();
    customExceptionExample();
  }

  // 1. TRY-CATCH-FINALLY
  static void tryCatchFinallyExample() {
    System.out.println("=== TRY-CATCH-FINALLY ===");
    int a = 10, b = 0;
    try {
      int result = a / b; // causes ArithmeticException
      System.out.println("Result: " + result);
    } catch (ArithmeticException e) {
      System.out.println("Caught Exception: " + e.getMessage());
    } finally {
      System.out.println("Finally block executed.");
    }
    System.out.println();
  }

  // 2. THROW & THROWS
  static void throwThrowsExample() {
    System.out.println("=== THROW & THROWS ===");
    try {
      validateAge(15); // throws exception manually
    } catch (Exception e) {
      System.out.println("Caught: " + e.getMessage());
    }
    System.out.println();
  }

  static void validateAge(int age) throws Exception {
    if (age < 18) {
      throw new Exception("Age must be 18 or older.");
    } else {
      System.out.println("Access granted.");
    }
  }

  // 3. CHECKED vs UNCHECKED
  static void checkedVsUncheckedExample() {
    System.out.println("=== CHECKED vs UNCHECKED ===");

    // Unchecked Exception: NullPointerException
    try {
      String str = null;
      System.out.println(str.length()); // causes NullPointerException
    } catch (NullPointerException e) {
      System.out.println("Unchecked Exception: " + e.getMessage());
    }

    // Checked Exception: InterruptedException (must be handled or declared)
    try {
      System.out.println("Sleeping for 1 second...");
      Thread.sleep(1000); // checked exception
    } catch (InterruptedException e) {
      System.out.println("Checked Exception: " + e.getMessage());
    }

    System.out.println();
  }

  // 4. CUSTOM EXCEPTION
  static void customExceptionExample() {
    System.out.println("=== CUSTOM EXCEPTION ===");

    try {
      login("admin", "1234"); // simulate wrong password
    } catch (LoginFailedException e) {
      System.out.println("Login Error: " + e.getMessage());
    }

    System.out.println();
  }

  // Method that uses custom exception
  static void login(String username, String password) throws LoginFailedException {
    if (!"admin".equals(username) || !"root".equals(password)) {
      throw new LoginFailedException("Invalid username or password.");
    } else {
      System.out.println("Login successful.");
    }
  }

  // Custom Exception class
  static class LoginFailedException extends Exception {
    public LoginFailedException(String message) {
      super(message);
    }
  }
}
