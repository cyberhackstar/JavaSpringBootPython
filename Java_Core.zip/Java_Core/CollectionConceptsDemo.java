import java.util.*;

public class CollectionConceptsDemo {

  public static void main(String[] args) {
    listExample();
    setExample();
    mapExample();
    queueDequeExample();
    iteratorExample();
    comparatorComparableExample();
  }

  // 1. LIST: ArrayList & LinkedList
  static void listExample() {
    System.out.println("=== LIST: ArrayList & LinkedList ===");

    List<String> arrayList = new ArrayList<>();
    arrayList.add("Java");
    arrayList.add("Python");
    arrayList.add("C++");

    List<String> linkedList = new LinkedList<>();
    linkedList.add("NodeJS");
    linkedList.add("Go");
    linkedList.add("Rust");

    System.out.println("ArrayList: " + arrayList);
    System.out.println("LinkedList: " + linkedList);
    System.out.println();
  }

  // 2. SET: HashSet & TreeSet
  static void setExample() {
    System.out.println("=== SET: HashSet & TreeSet ===");

    Set<Integer> hashSet = new HashSet<>();
    hashSet.add(10);
    hashSet.add(5);
    hashSet.add(20);
    hashSet.add(10); // duplicate will be ignored

    Set<Integer> treeSet = new TreeSet<>();
    treeSet.add(10);
    treeSet.add(5);
    treeSet.add(20);

    System.out.println("HashSet (Unordered): " + hashSet);
    System.out.println("TreeSet (Sorted): " + treeSet);
    System.out.println();
  }

  // 3. MAP: HashMap & TreeMap
  static void mapExample() {
    System.out.println("=== MAP: HashMap & TreeMap ===");

    Map<String, Integer> hashMap = new HashMap<>();
    hashMap.put("Alice", 30);
    hashMap.put("Bob", 25);
    hashMap.put("Charlie", 28);

    Map<String, Integer> treeMap = new TreeMap<>(hashMap); // auto-sorted by key

    System.out.println("HashMap (Unordered): " + hashMap);
    System.out.println("TreeMap (Sorted): " + treeMap);
    System.out.println();
  }

  // 4. QUEUE & DEQUE
  static void queueDequeExample() {
    System.out.println("=== QUEUE & DEQUE ===");

    Queue<String> queue = new LinkedList<>();
    queue.add("A");
    queue.add("B");
    queue.add("C");

    System.out.println("Queue: " + queue);
    System.out.println("Queue Poll: " + queue.poll());
    System.out.println("Queue After Poll: " + queue);

    Deque<String> deque = new ArrayDeque<>();
    deque.addFirst("Front");
    deque.addLast("Back");
    System.out.println("Deque: " + deque);
    System.out.println();
  }

  // 5. ITERATOR & LISTITERATOR
  static void iteratorExample() {
    System.out.println("=== ITERATOR & LISTITERATOR ===");

    List<String> languages = new ArrayList<>(Arrays.asList("Java", "Python", "C++"));

    Iterator<String> iterator = languages.iterator();
    System.out.print("Iterator Forward: ");
    while (iterator.hasNext()) {
      System.out.print(iterator.next() + " ");
    }

    ListIterator<String> listIterator = languages.listIterator(languages.size());
    System.out.print("\nListIterator Backward: ");
    while (listIterator.hasPrevious()) {
      System.out.print(listIterator.previous() + " ");
    }

    System.out.println("\n");
  }

  // 6. COMPARABLE & COMPARATOR
  static void comparatorComparableExample() {
    System.out.println("=== COMPARABLE & COMPARATOR ===");

    List<Employee> employees = new ArrayList<>();
    employees.add(new Employee("Alice", 50000));
    employees.add(new Employee("Bob", 60000));
    employees.add(new Employee("Charlie", 40000));

    // Comparable (by salary ascending)
    Collections.sort(employees);
    System.out.println("Sorted by Salary (Comparable):");
    for (Employee e : employees) {
      System.out.println(e.name + " - " + e.salary);
    }

    // Comparator (by name descending)
    employees.sort(new NameDescComparator());
    System.out.println("Sorted by Name (Comparator):");
    for (Employee e : employees) {
      System.out.println(e.name + " - " + e.salary);
    }

    System.out.println();
  }

  // Helper class for Comparable
  static class Employee implements Comparable<Employee> {
    String name;
    int salary;

    Employee(String name, int salary) {
      this.name = name;
      this.salary = salary;
    }

    // Default sorting: by salary
    public int compareTo(Employee o) {
      return Integer.compare(this.salary, o.salary);
    }
  }

  // Helper class for Comparator
  static class NameDescComparator implements Comparator<Employee> {
    public int compare(Employee e1, Employee e2) {
      return e2.name.compareTo(e1.name); // descending
    }
  }
}
