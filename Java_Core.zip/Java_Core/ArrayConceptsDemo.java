import java.util.Arrays;

public class ArrayConceptsDemo {

  public static void main(String[] args) {
    oneDAndTwoDArrays();
    arrayInitialization();
    arrayTraversal();
    arraySorting();
    arraySearching();
  }

  // 1. 1D & 2D Arrays
  static void oneDAndTwoDArrays() {
    System.out.println("=== 1D & 2D ARRAYS ===");

    // 1D Array
    int[] oneD = { 10, 20, 30 };
    System.out.println("1D Array:");
    for (int i = 0; i < oneD.length; i++) {
      System.out.print(oneD[i] + " ");
    }
    System.out.println();

    // 2D Array
    int[][] twoD = {
        { 1, 2, 3 },
        { 4, 5, 6 }
    };

    System.out.println("2D Array:");
    for (int i = 0; i < twoD.length; i++) {
      for (int j = 0; j < twoD[i].length; j++) {
        System.out.print(twoD[i][j] + " ");
      }
      System.out.println();
    }
    System.out.println();
  }

  // 2. Initialization
  static void arrayInitialization() {
    System.out.println("=== ARRAY INITIALIZATION ===");

    // Static Initialization
    int[] staticInit = { 5, 10, 15 };
    System.out.println("Static Init: " + Arrays.toString(staticInit));

    // Dynamic Initialization
    int[] dynamicInit = new int[3]; // default values = 0
    dynamicInit[0] = 7;
    dynamicInit[1] = 14;
    dynamicInit[2] = 21;

    System.out.println("Dynamic Init: " + Arrays.toString(dynamicInit));
    System.out.println();
  }

  // 3. Traversal
  static void arrayTraversal() {
    System.out.println("=== ARRAY TRAVERSAL ===");

    int[] arr = { 11, 22, 33, 44 };

    // For loop
    System.out.print("For loop: ");
    for (int i = 0; i < arr.length; i++) {
      System.out.print(arr[i] + " ");
    }

    System.out.print("\nEnhanced for loop: ");
    for (int num : arr) {
      System.out.print(num + " ");
    }

    System.out.println("\n");
  }

  // 4. Sorting
  static void arraySorting() {
    System.out.println("=== ARRAY SORTING ===");

    int[] unsorted = { 5, 3, 8, 1, 4 };
    System.out.println("Before sort: " + Arrays.toString(unsorted));

    Arrays.sort(unsorted); // Built-in sort (quick sort for primitives)
    System.out.println("After sort: " + Arrays.toString(unsorted));
    System.out.println();
  }

  // 5. Searching
  static void arraySearching() {
    System.out.println("=== ARRAY SEARCHING ===");

    int[] data = { 2, 4, 6, 8, 10 };
    int target = 6;

    // Linear Search
    boolean found = false;
    for (int i = 0; i < data.length; i++) {
      if (data[i] == target) {
        System.out.println("Linear Search: Found " + target + " at index " + i);
        found = true;
        break;
      }
    }
    if (!found) {
      System.out.println("Linear Search: " + target + " not found.");
    }

    // Binary Search (must be sorted)
    int[] sorted = { 1, 3, 5, 7, 9 };
    int binaryTarget = 7;
    int resultIndex = Arrays.binarySearch(sorted, binaryTarget);

    if (resultIndex >= 0) {
      System.out.println("Binary Search: Found " + binaryTarget + " at index " + resultIndex);
    } else {
      System.out.println("Binary Search: " + binaryTarget + " not found.");
    }

    System.out.println();
  }
}
