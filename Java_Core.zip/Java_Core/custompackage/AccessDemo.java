package custompackage;

public class AccessDemo {
  public String publicData = "Public Info";
  protected String protectedData = "Protected Info";
  String defaultData = "Default Info"; // no modifier = default
  private String privateData = "Private Info";

  public String getPrivateData() {
    return privateData;
  }
}
