package custompackage;

public class MyClass {
  public void showMessage() {
    System.out.println("Hello from a User-Defined Package (custompackage)!");
  }
}
