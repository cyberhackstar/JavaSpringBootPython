package custompackage;

// Save this as PackageConceptsDemo.java
import java.util.*; // Built-in package

public class PackageConceptsDemo {

  public static void main(String[] args) {
    builtInPackagesExample();
    userDefinedPackagesExample();
    accessLevelsExample();
  }

  // 1. BUILT-IN PACKAGES
  static void builtInPackagesExample() {
    System.out.println("=== BUILT-IN PACKAGES ===");

    List<String> list = new ArrayList<>();
    list.add("Java");
    list.add("Python");
    list.add("C++");

    System.out.println("ArrayList from java.util package: " + list);
    System.out.println();
  }

  // 2. USER-DEFINED PACKAGES
  static void userDefinedPackagesExample() {
    System.out.println("=== USER-DEFINED PACKAGES ===");

    // Using a class from our own package
    MyClass myObj = new MyClass();
    myObj.showMessage();

    System.out.println();
  }

  // 3. ACCESS LEVELS
  static void accessLevelsExample() {
    System.out.println("=== ACCESS LEVELS ===");

    AccessDemo accessDemo = new AccessDemo();

    // Public: accessible anywhere
    System.out.println("Public Data: " + accessDemo.publicData);

    // Protected: accessible in same package or subclasses
    System.out.println("Protected Data: " + accessDemo.protectedData);

    // Default (no modifier): accessible in same package
    System.out.println("Default Data: " + accessDemo.defaultData);

    // Private: NOT accessible directly (shows concept, uncommenting next line gives
    // compile error)
    // System.out.println("Private Data: " + accessDemo.privateData); // error

    System.out.println("Private Data accessed through getter: " + accessDemo.getPrivateData());
    System.out.println();
  }
}
