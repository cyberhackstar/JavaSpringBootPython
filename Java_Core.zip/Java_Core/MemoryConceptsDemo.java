public class MemoryConceptsDemo {

  public static void main(String[] args) throws InterruptedException {
    stackVsHeapExample();
    garbageCollectionExample();
    finalizeExample();
    memoryLeakExample();
  }

  // 1. STACK vs HEAP
  static void stackVsHeapExample() {
    System.out.println("=== STACK vs HEAP ===");

    int primitiveValue = 10; // Stored in Stack (value directly)

    MemoryConceptsDemo obj = new MemoryConceptsDemo(); // obj reference in Stack, actual object in Heap

    System.out.println("Primitive value (Stack): " + primitiveValue);
    System.out.println("Object (Heap) reference: " + obj);

    System.out.println();
  }

  // 2. GARBAGE COLLECTION
  static void garbageCollectionExample() {
    System.out.println("=== GARBAGE COLLECTION ===");

    GarbageObject g1 = new GarbageObject("G1");
    GarbageObject g2 = new GarbageObject("G2");

    g1 = null; // Eligible for GC
    g2 = null; // Eligible for GC

    System.gc(); // Suggest to JVM: "Please run GC now"

    System.out.println("Called System.gc()");
    System.out.println();
  }

  static class GarbageObject {
    String name;

    GarbageObject(String name) {
      this.name = name;
    }

    @Override
    protected void finalize() throws Throwable {
      System.out.println("Garbage Collected: " + name);
    }
  }

  // 3. finalize()
  static void finalizeExample() throws InterruptedException {
    System.out.println("=== finalize() ===");

    GarbageObject obj = new GarbageObject("FinalizeDemo");
    obj = null;

    System.gc(); // Suggest GC to call finalize()

    Thread.sleep(1000); // Give time for finalize() to show up
    System.out.println();
  }

  // 4. MEMORY LEAK
  static void memoryLeakExample() throws InterruptedException {
    System.out.println("=== MEMORY LEAK SIMULATION ===");

    MemoryLeakSimulator simulator = new MemoryLeakSimulator();
    simulator.simulateLeak();

    // For a real leak, you'd have to keep references alive unnecessarily
    System.out.println("Memory leak simulated (but Java GC is strong so no crash here).");

    System.out.println();
  }

  static class MemoryLeakSimulator {
    // Simulate leak by holding objects unnecessarily
    private static final java.util.List<byte[]> memoryHolder = new java.util.ArrayList<>();

    void simulateLeak() {
      for (int i = 0; i < 5; i++) {
        byte[] block = new byte[10 * 1024 * 1024]; // 10 MB block
        memoryHolder.add(block); // adding to static list -> memory never freed
        System.out.println("Allocated 10MB block " + (i + 1));
      }
    }
  }
}
