public class InnerClassConceptsDemo {

  public static void main(String[] args) {
    memberInnerClassExample();
    staticNestedClassExample();
    localInnerClassExample();
    anonymousInnerClassExample();
  }

  // 1. MEMBER INNER CLASS
  static void memberInnerClassExample() {
    System.out.println("=== MEMBER INNER CLASS ===");

    Outer outer = new Outer();
    Outer.Inner inner = outer.new Inner(); // Create inner class object using outer
    inner.display();

    System.out.println();
  }

  static class Outer {
    int outerValue = 10;

    class Inner {
      void display() {
        System.out.println("Accessing outer class value: " + outerValue);
      }
    }
  }

  // 2. STATIC NESTED CLASS
  static void staticNestedClassExample() {
    System.out.println("=== STATIC NESTED CLASS ===");

    StaticOuter.StaticInner inner = new StaticOuter.StaticInner();
    inner.show();

    System.out.println();
  }

  static class StaticOuter {
    static int staticValue = 20;

    static class StaticInner {
      void show() {
        System.out.println("Accessing static outer value: " + staticValue);
      }
    }
  }

  // 3. LOCAL INNER CLASS
  static void localInnerClassExample() {
    System.out.println("=== LOCAL INNER CLASS ===");

    class LocalInner {
      void msg() {
        System.out.println("Hello from Local Inner Class");
      }
    }

    LocalInner localInner = new LocalInner();
    localInner.msg();

    System.out.println();
  }

  // 4. ANONYMOUS INNER CLASS
  static void anonymousInnerClassExample() {
    System.out.println("=== ANONYMOUS INNER CLASS ===");

    Runnable r = new Runnable() {
      public void run() {
        System.out.println("Running thread using Anonymous Inner Class");
      }
    };

    Thread t = new Thread(r);
    t.start();

    try {
      t.join();
    } catch (InterruptedException ignored) {
    }

    System.out.println();
  }
}
