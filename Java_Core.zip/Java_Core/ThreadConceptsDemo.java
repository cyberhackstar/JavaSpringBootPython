import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadConceptsDemo {

  public static void main(String[] args) throws InterruptedException {
    threadClassExample();
    runnableInterfaceExample();
    threadLifecycleExample();
    synchronizationExample();
    waitNotifyExample();
    executorFrameworkExample();
  }

  // 1. THREAD CLASS
  static void threadClassExample() {
    System.out.println("=== THREAD CLASS ===");

    MyThread t1 = new MyThread();
    t1.start(); // start a new thread

    try {
      t1.join();
    } catch (InterruptedException ignored) {
    }
    System.out.println();
  }

  static class MyThread extends Thread {
    public void run() {
      System.out.println("Thread is running using Thread class.");
    }
  }

  // 2. RUNNABLE INTERFACE
  static void runnableInterfaceExample() {
    System.out.println("=== RUNNABLE INTERFACE ===");

    Thread t2 = new Thread(new MyRunnable());
    t2.start();

    try {
      t2.join();
    } catch (InterruptedException ignored) {
    }
    System.out.println();
  }

  static class MyRunnable implements Runnable {
    public void run() {
      System.out.println("Thread is running using Runnable interface.");
    }
  }

  // 3. THREAD LIFECYCLE
  static void threadLifecycleExample() throws InterruptedException {
    System.out.println("=== THREAD LIFECYCLE ===");

    Thread t3 = new Thread(() -> {
      System.out.println("Thread State: Running");
    });

    System.out.println("Thread State before start: " + t3.getState()); // NEW
    t3.start();
    Thread.sleep(100); // Give thread some time
    System.out.println("Thread State after completion: " + t3.getState()); // TERMINATED
    System.out.println();
  }

  // 4. SYNCHRONIZATION
  static void synchronizationExample() {
    System.out.println("=== SYNCHRONIZATION ===");

    Counter counter = new Counter();

    Thread t1 = new Thread(() -> {
      for (int i = 0; i < 1000; i++)
        counter.increment();
    });
    Thread t2 = new Thread(() -> {
      for (int i = 0; i < 1000; i++)
        counter.increment();
    });

    t1.start();
    t2.start();

    try {
      t1.join();
      t2.join();
    } catch (InterruptedException ignored) {
    }

    System.out.println("Counter Value (with synchronization): " + counter.count);
    System.out.println();
  }

  static class Counter {
    int count = 0;

    synchronized void increment() {
      count++;
    }
  }

  // 5. WAIT / NOTIFY
  static void waitNotifyExample() throws InterruptedException {
    System.out.println("=== WAIT / NOTIFY ===");

    SharedResource resource = new SharedResource();

    Thread producer = new Thread(() -> {
      synchronized (resource) {
        System.out.println("Producer thread running...");
        try {
          resource.wait(); // wait until notified
        } catch (InterruptedException e) {
          e.printStackTrace();
        }
        System.out.println("Producer thread resumed...");
      }
    });

    Thread consumer = new Thread(() -> {
      synchronized (resource) {
        System.out.println("Consumer thread running...");
        resource.notify(); // notify producer
      }
    });

    producer.start();
    Thread.sleep(1000); // Make sure producer waits
    consumer.start();

    producer.join();
    consumer.join();

    System.out.println();
  }

  static class SharedResource {
  }

  // 6. EXECUTOR FRAMEWORK
  static void executorFrameworkExample() {
    System.out.println("=== EXECUTOR FRAMEWORK ===");

    ExecutorService executor = Executors.newFixedThreadPool(2); // Pool of 2 threads

    executor.execute(() -> System.out.println("Task 1 executed"));
    executor.execute(() -> System.out.println("Task 2 executed"));
    executor.execute(() -> System.out.println("Task 3 executed"));

    executor.shutdown(); // No new tasks accepted
    System.out.println();
  }
}
