import java.util.StringTokenizer;

public class StringConceptsDemo {

    public static void main(String[] args) {
        stringExample();
        stringBuilderExample();
        stringBufferExample();
        commonMethodsExample();
        immutabilityExample();
        stringPoolExample();
        stringTokenizerExample();
    }

    // 1. STRING
    static void stringExample() {
        System.out.println("=== STRING EXAMPLE ===");
        String str1 = "Hello";
        String str2 = "World";
        String combined = str1 + " " + str2;
        System.out.println("Combined: " + combined);

        str1.concat(" Java"); // Won't change original
        System.out.println("After concat (str1): " + str1);
        System.out.println();
    }

    // 2. STRINGBUILDER
    static void stringBuilderExample() {
        System.out.println("=== STRINGBUILDER EXAMPLE ===");
        StringBuilder sb = new StringBuilder("Hello");
        sb.append(" Java");
        System.out.println("Appended: " + sb);
        sb.reverse();
        System.out.println("Reversed: " + sb);
        sb.reverse(); // reset
        System.out.println("Restored: " + sb);
        System.out.println();
    }

    // 3. STRINGBUFFER
    static void stringBufferExample() {
        System.out.println("=== STRINGBUFFER EXAMPLE ===");
        StringBuffer sbf = new StringBuffer("Secure");
        sbf.append(" Code");
        System.out.println("Appended: " + sbf);
        System.out.println();
    }

    // 4. COMMON METHODS
    static void commonMethodsExample() {
        System.out.println("=== COMMON STRING METHODS ===");
        String sample = "CyberSecurity";

        System.out.println("Length: " + sample.length());
        System.out.println("Char at 0: " + sample.charAt(0));
        System.out.println("Substring (0,5): " + sample.substring(0, 5));
        System.out.println("Contains 'Sec': " + sample.contains("Sec"));
        System.out.println("Replace 'Cyber' with 'Info': " + sample.replace("Cyber", "Info"));
        System.out.println("Index of 'S': " + sample.indexOf("S"));
        System.out.println();
    }

    // 5. IMMUTABILITY
    static void immutabilityExample() {
        System.out.println("=== IMMUTABILITY EXAMPLE ===");
        String immutableStr = "Hack";
        String modifiedStr = immutableStr.replace("H", "P");

        System.out.println("Original: " + immutableStr);
        System.out.println("Modified: " + modifiedStr);
        System.out.println();
    }

    // 6. STRING POOL
    static void stringPoolExample() {
        System.out.println("=== STRING POOL EXAMPLE ===");
        String s1 = "pool";
        String s2 = "pool";
        String s3 = new String("pool");

        System.out.println("s1 == s2: " + (s1 == s2)); // true
        System.out.println("s1 == s3: " + (s1 == s3)); // false
        System.out.println("s1.equals(s3): " + s1.equals(s3)); // true
        System.out.println();
    }

    // 7. STRINGTOKENIZER
    static void stringTokenizerExample() {
        System.out.println("=== STRINGTOKENIZER EXAMPLE ===");
        String tokens = "java,is,awesome";
        StringTokenizer tokenizer = new StringTokenizer(tokens, ",");

        while (tokenizer.hasMoreTokens()) {
            System.out.println("Token: " + tokenizer.nextToken());
        }
        System.out.println();
    }
}
