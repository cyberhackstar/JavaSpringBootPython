public class OOPConceptsDemo {

  public static void main(String[] args) {
    classAndObjectExample();
    constructorExample();
    thisAndSuperExample();
    inheritanceExample();
    polymorphismExample();
    overloadingAndOverridingExample();
    abstractionAndInterfaceExample();
    encapsulationExample();
  }

  // 1. CLASS & OBJECT
  static void classAndObjectExample() {
    System.out.println("=== CLASS & OBJECT ===");

    Car car = new Car();
    car.brand = "Tesla";
    car.display();

    System.out.println();
  }

  static class Car {
    String brand;

    void display() {
      System.out.println("Car brand is: " + brand);
    }
  }

  // 2. CONSTRUCTOR
  static void constructorExample() {
    System.out.println("=== CONSTRUCTOR ===");

    Student student = new Student("Alice", 22);
    student.display();

    System.out.println();
  }

  static class Student {
    String name;
    int age;

    Student(String name, int age) {
      this.name = name;
      this.age = age;
    }

    void display() {
      System.out.println("Student: " + name + ", Age: " + age);
    }
  }

  // 3. THIS & SUPER
  static void thisAndSuperExample() {
    System.out.println("=== THIS & SUPER ===");

    Child child = new Child();
    child.show();

    System.out.println();
  }

  static class Parent {
    int value = 100;
  }

  static class Child extends Parent {
    int value = 200;

    void show() {
      System.out.println("Child value: " + this.value); // current class
      System.out.println("Parent value: " + super.value); // parent class
    }
  }

  // 4. INHERITANCE
  static void inheritanceExample() {
    System.out.println("=== INHERITANCE ===");

    Dog dog = new Dog();
    dog.eat();
    dog.bark();

    System.out.println();
  }

  static class Animal {
    void eat() {
      System.out.println("This animal eats food.");
    }
  }

  static class Dog extends Animal {
    void bark() {
      System.out.println("Dog barks.");
    }
  }

  // 5. POLYMORPHISM
  static void polymorphismExample() {
    System.out.println("=== POLYMORPHISM ===");

    Animal myAnimal = new Dog(); // Parent ref -> Child object
    myAnimal.eat(); // Executes Animal's eat()
    // myAnimal.bark(); // ERROR: Parent reference can't access child methods
    // directly

    System.out.println();
  }

  // 6. OVERLOADING & OVERRIDING
  static void overloadingAndOverridingExample() {
    System.out.println("=== OVERLOADING & OVERRIDING ===");

    Calculator calc = new Calculator();
    System.out.println("Sum(int, int): " + calc.add(5, 10));
    System.out.println("Sum(double, double): " + calc.add(5.5, 10.5));

    AdvancedCalculator advCalc = new AdvancedCalculator();
    System.out.println("Advanced Sum(int, int): " + advCalc.add(5, 10)); // overridden method

    System.out.println();
  }

  static class Calculator {
    int add(int a, int b) {
      return a + b;
    }

    double add(double a, double b) {
      return a + b;
    }
  }

  static class AdvancedCalculator extends Calculator {
    @Override
    int add(int a, int b) {
      return a + b + 100; // Modified behavior
    }
  }

  // 7. ABSTRACTION & INTERFACE
  static void abstractionAndInterfaceExample() {
    System.out.println("=== ABSTRACTION & INTERFACE ===");

    Bike bike = new SportsBike();
    bike.start();

    Vehicle vehicle = new CarVehicle();
    vehicle.move();

    System.out.println();
  }

  // Abstract Class
  static abstract class Bike {
    abstract void start();
  }

  static class SportsBike extends Bike {
    @Override
    void start() {
      System.out.println("SportsBike starts quickly!");
    }
  }

  // Interface
  interface Vehicle {
    void move();
  }

  static class CarVehicle implements Vehicle {
    public void move() {
      System.out.println("Car moves on road.");
    }
  }

  // 8. ENCAPSULATION
  static void encapsulationExample() {
    System.out.println("=== ENCAPSULATION ===");

    Account account = new Account();
    account.setBalance(5000);
    System.out.println("Account Balance: " + account.getBalance());

    System.out.println();
  }

  static class Account {
    private int balance;

    public int getBalance() {
      return balance;
    }

    public void setBalance(int balance) {
      if (balance >= 0) {
        this.balance = balance;
      }
    }
  }
}
