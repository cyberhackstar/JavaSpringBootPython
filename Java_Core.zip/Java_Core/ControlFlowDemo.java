public class ControlFlowDemo {

  public static void main(String[] args) {
    operatorExamples();
    ifElseSwitchExample();
    loopExamples();
    breakContinueExample();
  }

  // 1. ARITHMETIC, RELATIONAL, LOGICAL, BITWISE OPERATORS
  static void operatorExamples() {
    System.out.println("=== OPERATORS ===");

    int a = 10, b = 5;

    // Arithmetic
    System.out.println("Add: " + (a + b));
    System.out.println("Sub: " + (a - b));
    System.out.println("Mul: " + (a * b));
    System.out.println("Div: " + (a / b));
    System.out.println("Mod: " + (a % b));

    // Relational
    System.out.println("a > b: " + (a > b));
    System.out.println("a == b: " + (a == b));

    // Logical
    boolean x = true, y = false;
    System.out.println("x && y: " + (x && y));
    System.out.println("x || y: " + (x || y));
    System.out.println("!x: " + (!x));

    // Bitwise
    int bitA = 5; // 0101
    int bitB = 3; // 0011
    System.out.println("bitA & bitB: " + (bitA & bitB)); // 0001 = 1
    System.out.println("bitA | bitB: " + (bitA | bitB)); // 0111 = 7

    System.out.println();
  }

  // 2. IF-ELSE, SWITCH
  static void ifElseSwitchExample() {
    System.out.println("=== IF-ELSE & SWITCH ===");

    int marks = 85;

    // if-else
    if (marks >= 90) {
      System.out.println("Grade: A");
    } else if (marks >= 75) {
      System.out.println("Grade: B");
    } else {
      System.out.println("Grade: C");
    }

    // switch
    int day = 3;
    switch (day) {
      case 1 -> System.out.println("Monday");
      case 2 -> System.out.println("Tuesday");
      case 3 -> System.out.println("Wednesday");
      default -> System.out.println("Invalid day");
    }

    System.out.println();
  }

  // 3. FOR, WHILE, DO-WHILE LOOPS
  static void loopExamples() {
    System.out.println("=== LOOPS ===");

    // for loop
    System.out.print("for: ");
    for (int i = 0; i < 3; i++) {
      System.out.print(i + " ");
    }

    // while loop
    System.out.print("\nwhile: ");
    int w = 0;
    while (w < 3) {
      System.out.print(w + " ");
      w++;
    }

    // do-while loop
    System.out.print("\ndo-while: ");
    int d = 0;
    do {
      System.out.print(d + " ");
      d++;
    } while (d < 3);

    System.out.println("\n");
  }

  // 4. BREAK & CONTINUE
  static void breakContinueExample() {
    System.out.println("=== BREAK & CONTINUE ===");

    // break
    System.out.print("break at 3: ");
    for (int i = 0; i < 6; i++) {
      if (i == 3)
        break;
      System.out.print(i + " ");
    }

    // continue
    System.out.print("\ncontinue at 3: ");
    for (int i = 0; i < 6; i++) {
      if (i == 3)
        continue;
      System.out.print(i + " ");
    }

    System.out.println("\n");
  }
}
