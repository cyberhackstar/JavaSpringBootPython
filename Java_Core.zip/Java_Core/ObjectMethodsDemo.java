public class ObjectMethodsDemo {

  public static void main(String[] args) throws CloneNotSupportedException {
    toStringExample();
    equalsExample();
    hashCodeExample();
    getClassExample();
    cloneExample();
  }

  // 1. toString()
  static void toStringExample() {
    System.out.println("=== toString() ===");

    Person person = new Person("Alice", 25);
    System.out.println(person.toString()); // calls overridden toString()

    System.out.println();
  }

  // 2. equals()
  static void equalsExample() {
    System.out.println("=== equals() ===");

    Person p1 = new Person("Bob", 30);
    Person p2 = new Person("Bob", 30);
    Person p3 = new Person("Charlie", 35);

    System.out.println("p1.equals(p2): " + p1.equals(p2)); // true (same content)
    System.out.println("p1.equals(p3): " + p1.equals(p3)); // false

    System.out.println();
  }

  // 3. hashCode()
  static void hashCodeExample() {
    System.out.println("=== hashCode() ===");

    Person p1 = new Person("Dave", 40);
    Person p2 = new Person("Dave", 40);

    System.out.println("p1.hashCode(): " + p1.hashCode());
    System.out.println("p2.hashCode(): " + p2.hashCode());

    System.out.println();
  }

  // 4. getClass()
  static void getClassExample() {
    System.out.println("=== getClass() ===");

    Person person = new Person("Eve", 28);

    System.out.println("Class Name: " + person.getClass().getName());
    System.out.println();
  }

  // 5. clone()
  static void cloneExample() throws CloneNotSupportedException {
    System.out.println("=== clone() ===");

    Person original = new Person("Frank", 22);
    Person cloned = (Person) original.clone();

    System.out.println("Original: " + original);
    System.out.println("Cloned: " + cloned);

    System.out.println();
  }

  // Helper class implementing Cloneable
  static class Person implements Cloneable {
    String name;
    int age;

    Person(String name, int age) {
      this.name = name;
      this.age = age;
    }

    @Override
    public String toString() {
      return "Person{name='" + name + "', age=" + age + "}";
    }

    @Override
    public boolean equals(Object obj) {
      if (this == obj)
        return true;
      if (obj == null || getClass() != obj.getClass())
        return false;

      Person person = (Person) obj;
      return age == person.age && name.equals(person.name);
    }

    @Override
    public int hashCode() {
      return name.hashCode() + age;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
      return super.clone();
    }
  }
}
