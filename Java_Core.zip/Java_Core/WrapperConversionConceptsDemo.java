public class WrapperConversionConceptsDemo {

  public static void main(String[] args) {
    wrapperClassesExample();
    autoboxingUnboxingExample();
    conversionsExample();
  }

  // 1. INTEGER, FLOAT, DOUBLE (WRAPPER CLASSES)
  static void wrapperClassesExample() {
    System.out.println("=== WRAPPER CLASSES ===");

    Integer intObj = Integer.valueOf(100);
    Float floatObj = Float.valueOf(12.34f);
    Double doubleObj = Double.valueOf(56.78);

    System.out.println("Integer Object: " + intObj);
    System.out.println("Float Object: " + floatObj);
    System.out.println("Double Object: " + doubleObj);

    // Primitive to Wrapper and vice versa
    int primitiveInt = intObj.intValue();
    System.out.println("Primitive int from Integer Object: " + primitiveInt);

    System.out.println();
  }

  // 2. AUTOBOXING & UNBOXING
  static void autoboxingUnboxingExample() {
    System.out.println("=== AUTOBOXING & UNBOXING ===");

    // Autoboxing: primitive to wrapper
    int a = 50;
    Integer aObj = a; // auto-conversion
    System.out.println("Autoboxed Integer: " + aObj);

    // Unboxing: wrapper to primitive
    Integer bObj = Integer.valueOf(100);
    int b = bObj; // auto-conversion
    System.out.println("Unboxed int: " + b);

    System.out.println();
  }

  // 3. CONVERSIONS
  static void conversionsExample() {
    System.out.println("=== CONVERSIONS ===");

    // String to int
    String numberStr = "123";
    int number = Integer.parseInt(numberStr);
    System.out.println("String to int: " + number);

    // int to String
    int num = 456;
    String numStr = Integer.toString(num);
    System.out.println("int to String: " + numStr);

    // Double to String
    double d = 78.90;
    String doubleStr = Double.toString(d);
    System.out.println("double to String: " + doubleStr);

    // String to double
    String strD = "34.56";
    double parsedD = Double.parseDouble(strD);
    System.out.println("String to double: " + parsedD);

    // int to double (implicit widening)
    int intVal = 10;
    double doubleVal = intVal;
    System.out.println("int to double (widening): " + doubleVal);

    System.out.println();
  }
}
